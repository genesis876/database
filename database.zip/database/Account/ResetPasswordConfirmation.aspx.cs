﻿using System.Web.UI;

namespace database.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}